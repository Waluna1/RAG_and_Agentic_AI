1. Introduction
Build a smart AI-powered Assistant as a web application using Flask and a Large language model. This project creates an intelligent application that will generate 
structured responses and leverage enterprise-grade AI tools. This will involve integration of watsonx.ai, implementation of JSON parsing, and engineer prompts that 
deliver consistent, actionable results.

2. Objectives
2.1 Develop a Flask web application integrated with AI capabilities.
2.2 Utilize the ibm-watsonx-ai library to interact with large language models.
2.3 Implement LangChain's JsonOutputParser for structured AI outputs.
2.4 Apply prompt engineering techniques for generating actionable JSON responses.
2.5 Compare and evaluate different language models including Llama, Granite, Mixtral.
2.6 Enhance your application with modular and reusable AI integration code.
2.7 Building GenAI applications with an emphasis on code quality, testing, and maintainability from day one. 

3. How Large Language Models Work
Large Language Models are thinking machines that can understand and generate human language with incredible fluency. Unlike traditional software that follows rigid 
rules, LLMs learn patterns from vast amounts of text to develop an intuitive understanding of language, knowledge, and reasoning. Think of them as having read millions
of books and learned to predict what comes next in any conversation.

3.1 Tokenization
Every journey begins with breaking text into digestible pieces called tokens. The sentence "Hello world" becomes separate tokens that the model can process. Using 
techniques like Byte Pair Encoding, common letter combinations become single tokens, while rare words get split apart. Each token gets assigned a unique number, 
transforming human language into mathematical data the model can understand.

3.2 Embeddings
These token numbers are then transformed into vectors - lists of hundreds of decimal numbers that capture meaning in mathematical space. Words with similar meanings 
cluster together in this high-dimensional space, like "cat" and "dog" being closer than "cat" and "airplane."

3.3 Transformers
Transformer's attention mechanisms: As the model processes each word, it simultaneously looks at every other word in the sentence to 
understand relationships and context. When processing "The cat sat on the mat," the model learns that "sat" relates most strongly to "cat" as the subject performing 
the action. Multiple attention heads work in parallel, each specializing in different types of relationships like grammar, meaning, or long-range dependencies.
These attention mechanisms stack into layers. Information flows upward through dozens of layers, with each one building more sophisticated representations. Early 
layers might focus on basic grammar and word relationships, while deeper layers develop complex reasoning abilities and factual knowledge. To keep this flow stable, 
the model also passes forward the original input of each layer alongside the new transformations. This helps preserve important details and prevents information from 
being lost or distorted as it moves through many layers.

Next Token Prediction: The model's training objective is easy enough: predict the next word in a sequence. Given "The capital of France is," it learns to predict "Paris." But this simple 
task teaches remarkable complexity - grammar, facts, reasoning, and even creativity. The model learns that language follows patterns, and these patterns encode the 
structure of how humans think.

3.4 Training
Training happens on an enormous scale that's hard to comprehend. The model processes trillions of words from books, articles, and websites, learning from the 
collective knowledge of the internet and beyond. Thousands of powerful computers work together for months, adjusting billions of parameters through backpropagation. 
Each time the model makes a wrong prediction, it slightly adjusts its internal connections to do better next time.

3.5 Inference
During actual use, the trained model generates text one token at a time. It considers everything you've said, processes it through all its layers of understanding, 
and predicts the most appropriate next word. That word gets added to the conversation and fed back in to predict the following word, creating a chain of coherent 
thought. Temperature and sampling controls the trade-off between creativity versus consistency.

3.6 Summary
Through this process of learning from human text, these models develop something remarkably close to understanding. They learn not just to parrot back information, 
but to reason, create, and engage in sophisticated dialogue. 

4. Setting Up the Development Environment
The development will take place within a Cloud IDE. This environment is based on Ubuntu 22.04 and provides all the tools you need to build your AI-driven Flask 
application.

4.1 Step 1: Create the Project Directory

4.1.1 Open the terminal in Cloud IDE and run:
mkdir genai_flask_app
cd genai_flask_app

This creates a new directory for your project and navigates into it.

4.2 Step 2: Set Up a Python Virtual Environment
4.2.1 Initialize a new Python virtual environment:
python3.11 -m venv venv
source venv/bin/activate

5. Creating a Flask Application
5.1 Leu us start by creating the backbone of your Flask application. We'll set up a basic structure that we'll enhance with AI  capabilities in the following steps. 
Before we start coding, let's install the Flask and LangChain libraries:

pip install Flask langchain-ibm langchain

# This command installs:
# Flask for web development
# LangChain libraries for advanced AI capabilities

5.2 Step 1: Create Your Main Application File
Create a new file named app.py:

from flask import Flask, request, jsonify 	# Import necessary modules from Flask.

app = Flask(__name__)				# Create a Flask application instance.				

@app.route('/generate', methods=['POST'])	# Define a route /generate that will handle POST requests. This is where our AI logic will go.
def generate():					# Returns a simple JSON response.
    # This is where we'll add our AI logic later
    return jsonify({"message": "AI response will be generated here"})

if __name__ == '__main__':			# The if __name__ == '__main__': block ensures the Flask development server runs when we execute this file directly.
    app.run(debug=True)

6. Integrating AI Models with LangChain
Now, let's integrate AI capabilities into your Flask application using the langchain library and various language models. We'll focus on creating a modular structure 
for easy maintenance and expansion.

6.1 Step 1: Create a Model Configuration File
First, let's create a configuration file to store our model parameters and credentials. Create a new file named config.py:
from ibm_watsonx_ai.metanames import GenTextParamsMetaNames as GenParams

# Model parameters
PARAMETERS = {
    GenParams.DECODING_METHOD: "greedy",
    GenParams.MAX_NEW_TOKENS: 256,
}

# watsonx credentials
# Note: Normally we'd need an API key, but in Skill's Network Cloud IDE will automatically handle that for you.
CREDENTIALS = {
    "url": "https://us-south.ml.cloud.ibm.com",
    "project_id": "skills-network"
}

# Model IDs
LLAMA_MODEL_ID = "meta-llama/llama-4-maverick-17b-128e-instruct-fp8"
GRANITE_MODEL_ID = "ibm/granite-4-h-small"
MISTRAL_MODEL_ID = "mistralai/mistral-small-3-1-24b-instruct-2503"

6.2 Step 2: Create a Model Integration File
Now, let's create a file to handle our AI model integration. Create a new file named model.py:

from langchain_ibm import ChatWatsonx
from langchain_core.prompts import PromptTemplate
from config import PARAMETERS, LLAMA_MODEL_ID, GRANITE_MODEL_ID, MISTRAL_MODEL_ID

Let's break down the imports: 
1. ChatWatsonx will be our interface to interact with IBM Watsonx AI models.
2. PromptTemplate allows us to create dynamic prompts with placeholders for AI input.
3. PARAMETERS, LLAMA_MODEL_ID, etc. are the configuration values we defined earlier to set up our different AI models.

7. Model Initialisation
# Function to initialize a model
def initialize_model(model_id):
    return ChatWatsonx(
        model_id=model_id,
        url="https://us-south.ml.cloud.ibm.com",
        project_id="skills-network",
        params=PARAMETERS
    )

# Initialize models
llama_llm = initialize_model(LLAMA_MODEL_ID)
granite_llm = initialize_model(GRANITE_MODEL_ID)
mistral_llm = initialize_model(MISTRAL_MODEL_ID)

We will once again initialize our models, this time we're going to take advantage of LangChain's ChatWatsonx, a wrapper for WatsonX API client.

7.1 To make our prompts more reusable and adaptable across our chats, we can use the PromptTemplate class. This allows us to define templates with placeholders that 
can be filled dynamically at runtime with specific inputs.
By defining placeholders like system_prompt, and user_prompt, these templates can be reused with different content, making them flexible for various interactions with
AI models.

# Prompt template
llama_template = PromptTemplate(
    template='''<|begin_of_text|><|start_header_id|>system<|end_header_id|>
{system_prompt}<|eot_id|><|start_header_id|>user<|end_header_id|>
{user_prompt}<|eot_id|><|start_header_id|>assistant<|end_header_id|>
''',
    input_variables=["system_prompt", "user_prompt"]
)

granite_template = PromptTemplate(
    template="<|system|>{system_prompt}\n\<|user|>{user_prompt}\n<|assistant|>",
    input_variables=["system_prompt", "user_prompt"]
)

mistral_template = PromptTemplate(
    template="<s>[INST]{system_prompt}\n{user_prompt}[/INST]",
    input_variables=["system_prompt", "user_prompt"]
)

7.2 By defining placeholders like system_prompt, and user_prompt, these templates can be reused with different content, making them flexible for various interactions 
with AI models.

def get_ai_response(model, template, system_prompt, user_prompt):
    chain = template | model
    return chain.invoke({'system_prompt':system_prompt, 'user_prompt':user_prompt})

# The function get_ai_response allows us to chain a prompt template and an AI model together. We can using the pipe operator|to directly take the output of the template 
# and use that as the input of the model.

7.3 Model-specific response functions
The model-specific functions each call this generic function with the respective models and templates, ensuring that the appropriate format is used for each AI model 
when generating responses.

# Model-specific response functions
def llama_response(system_prompt, user_prompt):
    return get_ai_response(llama_llm, llama_template, system_prompt, user_prompt)

def granite_response(system_prompt, user_prompt):
    return get_ai_response(granite_llm, granite_template, system_prompt, user_prompt)

def mistral_response(system_prompt, user_prompt):
    return get_ai_response(mistral_llm, mistral_template, system_prompt, user_prompt)

Let's break down this code:
1. Import necessary modules and our configuration.
2. Define a function initialize_model to create model instances, promoting code reuse.
3. Initialize the models using this function.
4. Create prompt templates for each model, as they may have different preferred formats.
5. The get_ai_response function handles the process of formatting prompts, getting responses
6. Define model-specific response functions that use the general get_ai_response function.
This modular approach allows for easy addition of new models or modification of existing ones.

8. Sanity Check
8.1 Give all our models a test run by calling them all together as a function.

8.2 Create the file llm_test.py:
from model import llama_response, granite_response, mistral_response

def call_all_models(system_prompt, user_prompt):
    llama_result = llama_response(system_prompt, user_prompt)
    granite_result = granite_response(system_prompt, user_prompt)
    mistral_result = mistral_response(system_prompt, user_prompt)

    print("Llama Response:\n", llama_result.content)
    print("\nGranite Response:\n", granite_result.content)
    print("\nMistral Response:\n", mistral_result.content)

# Example call to test all models
call_all_models("You are a helpful assistant who provides concise and accurate answers", "What is the capital of Canada? Tell me a cool fact about it as well")

9. Setting up JSON outputs
9.1 To making sure the AI’s output follows a well-defined format, it is essential to take the output and seamlessly integrate it into other systems, like a website.
We can use Pydantic to define a clear schema for the AI’s response, ensuring consistent structure and validation. This enforces the correct format, making data 
integration smoother and more reliable:

from pydantic import BaseModel, Field
from langchain_core.output_parsers import JsonOutputParser

We'll use BaseModel and Field to define our JSON output structure. To make our lives a bit easier, we will also use JsonOutputParser to automatically parse and validate 
the AI’s output into the structured format we’ve defined.

9.2 Pydantic Model

# Define JSON output structure
class AIResponse(BaseModel):
    summary: str = Field(description="Summary of the user's message")
    sentiment: int = Field(description="Sentiment score from 0 (negative) to 100 (positive)")
    response: str = Field(description="Suggested response to the user")

To seamlessly integrate this structure into our code, we use the JsonOutputParser. This parser ensures that the output returned by the AI is automatically validated 
and parsed into the AIResponseformat.

9.3 JSON Output Parser

# JSON output parser
json_parser = JsonOutputParser(pydantic_object=AIResponse)

# Here, we define the expected output using the AIResponse Pydantic model, specifying fields like summary, sentiment, action, and response. The JsonOutputParser will 
# ensure that the AI output conforms to this structure, providing well-formatted, validated data for further use in our application.

9.4 Updating the Chain

def get_ai_response(model, template, system_prompt, user_prompt):
    chain = template | model | json_parser
    return chain.invoke({'system_prompt':system_prompt, 'user_prompt':user_prompt, 'format_prompt':json_parser.get_format_instructions()})

# We add the json_parser to our chain and call json_parser.get_format_instructions() which will ultimately update our prompt with instructions to respond in 
well-structured JSON as defined by the AIResponse class.

10. Putting it all Together
Finally add addAIResponse and json_parserto the top of model.py as well as adding adding another link to our chain object within get_ai_response. 
The final code is in the project folder.

11. Enhancing the Flask Application with AI Capabilities
Now that we have our AI models set up, let's integrate them into our Flask application.

11.1 Step 1: Update the Flask Application

from flask import Flask, request, jsonify, render_template
from model import llama_response, granite_response, mistral_response
import time

app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate():
    data = request.json
    user_message = data.get('message')
    model = data.get('model')
    
    if not user_message or not model:
        return jsonify({"error": "Missing message or model selection"}), 400
    
    system_prompt = "You are an AI assistant helping with customer inquiries. Provide a helpful and concise response."
    
    start_time = time.time()
    
    try:
        if model == 'llama':
            result = llama_response(system_prompt, user_message)
        elif model == 'granite':
            result = granite_response(system_prompt, user_message)
        elif model == 'mistral':
            result = mistral_response(system_prompt, user_message)
        else:
            return jsonify({"error": "Invalid model selection"}), 400
        
        result['duration'] = time.time() - start_time
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)

Let's break down the code:
1. Import our model-specific response functions.
2. In the /generate route, we now expect JSON input with 'message' and 'model' fields.
3. Add error handling for missing inputs.
4. Use a try-except block to handle potential errors in AI processing.
5. Measure and include the processing time in the response.
This setup allows us to handle requests for different models and provides robust error handling.

11.2 Step 2: Create the Simple HTML file
Create the file templates/index.html:

Update the content of templates/index.html with:

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Assistant</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:ital,wght@0,300;0,400;0,500;0,600;1,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/static/styles.css">
</head>
<body class="font-ibm-plex">
    <div class="app-container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <h1 class="header-title">AI Assistant</h1>
                <button id="clearBtn" class="clear-btn" style="display: none;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="m3 6 18 0"></path>
                        <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                        <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                    </svg>
                    Clear Chat
                </button>
            </div>
        </div>

        <!-- Chat Container -->
        <div class="chat-container">
            <!-- Messages Area -->
            <div class="messages-area">
                <div class="messages-content">
                    <!-- Welcome Screen -->
                    <div id="welcomeScreen" class="welcome-screen">
                        <div class="welcome-icon">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
                                <path d="M8 14s1.5 2 4 2 4-2 4-2"/>
                                <line x1="9" y1="9" x2="9.01" y2="9"/>
                                <line x1="15" y1="9" x2="15.01" y2="9"/>
                            </svg>
                        </div>
                        <h2 class="welcome-title">Welcome to AI Assistant</h2>
                        <p class="welcome-text">Choose a model and start a conversation. I'm here to help with your questions and tasks.</p>
                    </div>

                    <!-- Messages Container -->
                    <div id="messagesContainer" class="messages-container"></div>

                    <!-- Loading Indicator -->
                    <div id="loadingIndicator" class="loading-indicator" style="display: none;">
                        <div class="loading-bubble">
                            <div class="loading-content">
                                <div class="loading-dots">
                                    <div class="dot"></div>
                                    <div class="dot"></div>
                                    <div class="dot"></div>
                                </div>
                                <span class="loading-text">AI is thinking...</span>
                            </div>
                        </div>
                    </div>

                    <!-- Messages End -->
                    <div id="messagesEnd"></div>
                </div>
            </div>

            <!-- Input Area -->
            <div class="input-area">
                <div class="input-content">
                    <form id="chatForm" class="chat-form">
                        <!-- Model Selection -->
                        <div class="model-section">
                            <span class="model-label">Model:</span>
                            <div class="select-wrapper">
                                <select id="modelSelect" class="model-select">
                                    <option value="llama">Llama</option>
                                    <option value="granite">Granite</option>
                                    <option value="mistral">Mistral</option>
                                </select>
                            </div>
                        </div>

                        <!-- Message Input -->
                        <div class="input-section">
                            <div class="textarea-container">
                                <textarea 
                                    id="messageInput" 
                                    class="message-textarea"
                                    placeholder="Type your message... (Enter to send, Shift+Enter for new line)"
                                    rows="1"
                                ></textarea>
                            </div>
                            
                            <button type="submit" id="sendButton" class="send-button">
                                <svg id="sendIcon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="22" y1="2" x2="11" y2="13"></line>
                                    <polygon points="22,2 15,22 11,13 2,9 22,2"></polygon>
                                </svg>
                                <div id="loadingSpinner" class="loading-spinner" style="display: none;">
                                    <div class="spinner"></div>
                                </div>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="/static/script.js"></script>
</body>
</html>

This is a simple HTML that will give us a form allowing us to call the /generate endpoint, passing a message and model selection.

11.3 Step 3: Adding CSS and JavaScript to Flask
When building a Flask web application, the HTML templates define the structure and content of your pages, but to make them visually appealing and interactive, we'll 
need to add CSS and JavaScript. Flask serves these static assets from a dedicated static folder. The CSS and JavaScript code for the frontend of this website is quite 
long, so instead of embedding it directly in the markdown (which would be messy and hard to read), we’ve kept things clean by hosting the files separately. To add the 
code, we can create a static folder in our Flask project and download the files from a GitHub Gist. Execute the below commands in the terminal one by one in order:

mkdir static

wget -O static/script.js "https://gist.githubusercontent.com/tenzinmigmar/0168709391266a8d8da7936f1a866c71/raw/95f4f4e1a1966b3f5183dd2f822cfcfd08d2238a/script.js"

wget -O static/styles.css "https://gist.githubusercontent.com/tenzinmigmar/278575598f79a4940993a1fc8640a60a/raw/24eda98885e854b01b4a46d1756112e91d3acc10/styles.css"

11.4 Step 4: Testing the AI-Enabled Application
First let's run our Flask application, execute:

python app.py

You should see output indicating that the Flask development server is running on port 5000.
The Flask application is now running locally on Cloud IDE.

11.5 Results: Refer to:
1. image "Sanity_check_outout.png"
2. Model_Tesing.png

12 Conclusion
12.1 Key Takeaways
1. Learned how to set up a Flask application with AI capabilities.
2. Integrated and compared multiple language models (Llama, Granite, Mistral).
3. Implemented LangChain's JsonOutputParser for structured AI outputs.
4. Gained insights into prompt engineering and model performance analysis.
5. Created a modular and maintainable codebase for AI integration.

12.2 Next Steps
To further enhance Agentic AI skills and application:
1. Implement Caching: Add a caching mechanism to improve performance for repeated queries.
2. Explore Advanced LangChain Features: Look into features like memory for maintaining conversation context.
3. Add More Models: Try integrating other models available through watsonx.ai.
4. Implement A/B Testing: Create a system to compare responses from different models for the same query.
5. Enhance Error Handling: Implement more robust error handling and logging.
6. Explore IBM Cloud Services: Consider integrating other IBM Cloud services to expand your application's capabilities.












