1. Introduction
This document introduces a practical project that demonstrates how to integrate Chroma DB with Python for employee data analysis using vector embeddings and similarity
search. It outlines clear objectives, including creating a collection for employee records, generating embeddings from key attributes, and performing advanced search 
operations. The guide walks through environment setup, code implementation, and embedding generation, while also showcasing how to enrich employee data with meaningful
text descriptions. By combining semantic similarity search with metadata filtering, the project highlights powerful query capabilities that can be applied to 
real-world scenarios such as talent matching, role identification, and workforce analytics.

2. Objectives:
	2.1 Create a collection for employee data and store related data in a Chroma DB collection.
	2.2 Generate numeric representations for specific key-value pairs of the employee dataset and convert them into vector embeddings.
	2.3 Store related data in a Chroma DB collection.
	2.4 Perform similarity search on vector embeddings that you create and display similar results based on a query.

3. Set up the Environment
3.1 In the Visual Studio IDE environment create a new terminal.
3.2 Install the required Python packages to work with Chroma DB. First, install chromadb in the environment to work with the Chroma DB vector database. Execute the 
following command in the terminal window:

pip install chromadb==1.0.12

3.3 Install the SentenceTransformers dependency by executing the following command in terminal window:

pip install sentence-transformers==4.1.0

3.4 Now, within the IDE environment, create a Python file named "similarity_employeedata.py" - Use this file to create the code logic to analyze employee data.

4. Create a Collection and Embed Data

4.1 Import the necessary modules from the chromadb package. By importing these classes, you can create an instance of the client that interacts with the Chroma DB 
database and define the embedding model. Include the following command in the similarity_employeedata.py file:

# Importing necessary modules from the chromadb package:
# chromadb is used to interact with the Chroma DB database,
# embedding_functions is used to define the embedding model
import chromadb
from chromadb.utils import embedding_functions

# Define the embedding function using SentenceTransformers
# This function will be used to generate embeddings (vector representations) for the data
ef = embedding_functions.SentenceTransformerEmbeddingFunction(
    model_name="all-MiniLM-L6-v2"
)

# Creating an instance of ChromaClient to establish a connection with the Chroma database
client = chromadb.Client()

# This code imports necessary modules from Chroma DB, including the main chromadb library for interacting with the database and embedding_functions to define the 
# embedding model using SentenceTransformers.

4.2 Initialize the collection_name variable and specify the name of the collection as shown below:

# Defining a name for the collection where data will be stored or accessed
# This collection is likely used to group related records, such as employee data
collection_name = "employee_collection"

4.3 Now create the main function, which you must define as a function. This function will contain the code to create collection, generate embeddings and perform 
similarity search.

# Defining a function named 'main'
# This function is used to encapsulate the main operations for creating collections,
# generating embeddings, and performing similarity search
def main():
    try:
        # Code for database operations will be placed here
        # This includes creating collections, adding data, and performing searches
        pass
    except Exception as error:
        # Catching and handling any errors that occur within the 'try' block
        # Logs the error message to the console for debugging purposes
        print(f"Error: {error}")

4.4 Then create a collection inside the database and perform the following command inside the try block of the main function:

# Creating a collection using the ChromaClient instance
# The 'create_collection' method creates a new collection with the specified configuration
collection = client.create_collection(
    # Specifying the name of the collection to be created
    name=collection_name,
    # Adding metadata to describe the collection
    metadata={"description": "A collection for storing employee data"},
    # Configuring the collection with cosine distance and embedding function
    configuration={
        "hnsw": {"space": "cosine"},
        "embedding_function": ef
    }
)
print(f"Collection created: {collection.name}")

# This code creates a collection named "employee_collection" from the database using the client's create_collection method.
# This method creates a new collection in the database with the specified name and configuration.
# The collection variable holds a reference to this collection for further operations and is configured to use the SentenceTransformer embedding function to generate 
# embeddings for text data.

4.5 Next, after creating a collection inside the try block, define the sample data of employees. Include the given employees array after you have declared the 
collection:

		# Defining a list of employee dictionaries
		# Each dictionary represents an individual employee with comprehensive information
		employees = [
			{
				"id": "employee_1",
				"name": "John Doe",
				"experience": 5,
				"department": "Engineering",
				"role": "Software Engineer",
				"skills": "Python, JavaScript, React, Node.js, databases",
				"location": "New York",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_2",
				"name": "Jane Smith",
				"experience": 8,
				"department": "Marketing",
				"role": "Marketing Manager",
				"skills": "Digital marketing, SEO, content strategy, analytics, social media",
				"location": "Los Angeles",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_3",
				"name": "Alice Johnson",
				"experience": 3,
				"department": "HR",
				"role": "HR Coordinator",
				"skills": "Recruitment, employee relations, HR policies, training programs",
				"location": "Chicago",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_4",
				"name": "Michael Brown",
				"experience": 12,
				"department": "Engineering",
				"role": "Senior Software Engineer",
				"skills": "Java, Spring Boot, microservices, cloud architecture, DevOps",
				"location": "San Francisco",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_5",
				"name": "Emily Wilson",
				"experience": 2,
				"department": "Marketing",
				"role": "Marketing Assistant",
				"skills": "Content creation, email marketing, market research, social media management",
				"location": "Austin",
				"employment_type": "Part-time"
			},
			{
				"id": "employee_6",
				"name": "David Lee",
				"experience": 15,
				"department": "Engineering",
				"role": "Engineering Manager",
				"skills": "Team leadership, project management, software architecture, mentoring",
				"location": "Seattle",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_7",
				"name": "Sarah Clark",
				"experience": 8,
				"department": "HR",
				"role": "HR Manager",
				"skills": "Performance management, compensation planning, policy development, conflict resolution",
				"location": "Boston",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_8",
				"name": "Chris Evans",
				"experience": 20,
				"department": "Engineering",
				"role": "Senior Architect",
				"skills": "System design, distributed systems, cloud platforms, technical strategy",
				"location": "New York",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_9",
				"name": "Jessica Taylor",
				"experience": 4,
				"department": "Marketing",
				"role": "Marketing Specialist",
				"skills": "Brand management, advertising campaigns, customer analytics, creative strategy",
				"location": "Miami",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_10",
				"name": "Alex Rodriguez",
				"experience": 18,
				"department": "Engineering",
				"role": "Lead Software Engineer",
				"skills": "Full-stack development, React, Python, machine learning, data science",
				"location": "Denver",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_11",
				"name": "Hannah White",
				"experience": 6,
				"department": "HR",
				"role": "HR Business Partner",
				"skills": "Strategic HR, organizational development, change management, employee engagement",
				"location": "Portland",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_12",
				"name": "Kevin Martinez",
				"experience": 10,
				"department": "Engineering",
				"role": "DevOps Engineer",
				"skills": "Docker, Kubernetes, AWS, CI/CD pipelines, infrastructure automation",
				"location": "Phoenix",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_13",
				"name": "Rachel Brown",
				"experience": 7,
				"department": "Marketing",
				"role": "Marketing Director",
				"skills": "Strategic marketing, team leadership, budget management, campaign optimization",
				"location": "Atlanta",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_14",
				"name": "Matthew Garcia",
				"experience": 3,
				"department": "Engineering",
				"role": "Junior Software Engineer",
				"skills": "JavaScript, HTML/CSS, basic backend development, learning frameworks",
				"location": "Dallas",
				"employment_type": "Full-time"
			},
			{
				"id": "employee_15",
				"name": "Olivia Moore",
				"experience": 12,
				"department": "Engineering",
				"role": "Principal Engineer",
				"skills": "Technical leadership, system architecture, performance optimization, mentoring",
				"location": "San Francisco",
				"employment_type": "Full-time"
			},
		]

5. Generate Embeddings and Add Texts to a Collection
5.1 Next, create meaningful text documents from employee data that will enable actual similarity searches. Instead of just using experience numbers, we'll create rich 
text descriptions that combine multiple employee attributes:

# Create comprehensive text documents for each employee
# These documents will be used for similarity search based on skills, roles, and experience
employee_documents = []
for employee in employees:
    document = f"{employee['role']} with {employee['experience']} years of experience in {employee['department']}. "
    document += f"Skills: {employee['skills']}. Located in {employee['location']}. "
    document += f"Employment type: {employee['employment_type']}."
    employee_documents.append(document)

5.2 Next, add the IDs, documents, and comprehensive metadata to the collection:

# Adding data to the collection in the Chroma database
# The 'add' method inserts or updates data into the specified collection
collection.add(
    # Extracting employee IDs to be used as unique identifiers for each record
    ids=[employee["id"] for employee in employees],
    # Using the comprehensive text documents we created
    documents=employee_documents,
    # Adding comprehensive metadata for filtering and search
    metadatas=[{
        "name": employee["name"],
        "department": employee["department"],
        "role": employee["role"],
        "experience": employee["experience"],
        "location": employee["location"],
        "employment_type": employee["employment_type"]
    } for employee in employees]
)

# By passing these pieces of information using the add method of the collection, the code adds the documents along with their corresponding IDs and comprehensive 
# metadata to the Chroma DB database collection. This approach enables both semantic similarity search (through the text documents) and precise filtering 
# (through the metadata), making it suitable for realistic employee search scenarios.

5.3 You can use the following code, which uses the get method, to access all items:

# Retrieving all items from the specified collection
# The 'get' method fetches all records stored in the collection
all_items = collection.get()
# Logging the retrieved items to the console for inspection or debugging
print("Collection contents:")
print(f"Number of documents: {len(all_items['documents'])}")

# all_items - This line of code declares a variable named all_items to store the result of the collection.get() method. This variable holds the items retrieved from 
the collection, which includes the documents, IDs, and metadata.
# collection.get() - This method retrieves all data items stored within the collection. These items include the documents, their corresponding IDs, and their metadata.

6. Perform Similarity Search, Metadata Filtering, and Full-Text Search
6.1 Create a function named perform_advanced_search after the main function, where you will demonstrate different types of searches including similarity search, 
metadata filtering, and combinations of both:

# Function to perform various types of searches within the collection
def perform_advanced_search(collection, all_items):
    try:
        # Advanced search operations will be placed here
        pass
    except Exception as error:
        print(f"Error in advanced search: {error}")

6.2 Inside this function, implement similarity search using natural language queries. This demonstrates how Chroma DB can find semantically similar content:

print("=== Similarity Search Examples ===")

# Example 1: Search for Python developers
print("\n1. Searching for Python developers:")
query_text = "Python developer with web development experience"
results = collection.query(
    query_texts=[query_text],
    n_results=3
)
print(f"Query: '{query_text}'")
for i, (doc_id, document, distance) in enumerate(zip(
    results['ids'][0], results['documents'][0], results['distances'][0]
)):
    metadata = results['metadatas'][0][i]
    print(f"  {i+1}. {metadata['name']} ({doc_id}) - Distance: {distance:.4f}")
    print(f"     Role: {metadata['role']}, Department: {metadata['department']}")
    print(f"     Document: {document[:100]}...")

# Example 2: Search for leadership roles
print("\n2. Searching for leadership and management roles:")
query_text = "team leader manager with experience"
results = collection.query(
    query_texts=[query_text],
    n_results=3
)
print(f"Query: '{query_text}'")
for i, (doc_id, document, distance) in enumerate(zip(
    results['ids'][0], results['documents'][0], results['distances'][0]
)):
    metadata = results['metadatas'][0][i]
    print(f"  {i+1}. {metadata['name']} ({doc_id}) - Distance: {distance:.4f}")
    print(f"     Role: {metadata['role']}, Experience: {metadata['experience']} years")

6.3 Now implement metadata filtering to find employees based on specific criteria:
print("\n=== Metadata Filtering Examples ===")

# Example 1: Filter by department
print("\n3. Finding all Engineering employees:")
results = collection.get(
    where={"department": "Engineering"}
)
print(f"Found {len(results['ids'])} Engineering employees:")
for i, doc_id in enumerate(results['ids']):
    metadata = results['metadatas'][i]
    print(f"  - {metadata['name']}: {metadata['role']} ({metadata['experience']} years)")

# Example 2: Filter by experience range
print("\n4. Finding employees with 10+ years experience:")
results = collection.get(
    where={"experience": {"$gte": 10}}
)
print(f"Found {len(results['ids'])} senior employees:")
for i, doc_id in enumerate(results['ids']):
    metadata = results['metadatas'][i]
    print(f"  - {metadata['name']}: {metadata['role']} ({metadata['experience']} years)")

# Example 3: Filter by location
print("\n5. Finding employees in California:")
results = collection.get(
    where={"location": {"$in": ["San Francisco", "Los Angeles"]}}
)
print(f"Found {len(results['ids'])} employees in California:")
for i, doc_id in enumerate(results['ids']):
    metadata = results['metadatas'][i]
    print(f"  - {metadata['name']}: {metadata['location']}")

6.4 Finally, combine similarity search with metadata filtering for more precise results:

print("\n=== Combined Search: Similarity + Metadata Filtering ===")

# Example: Find experienced Python developers in specific locations
print("\n6. Finding senior Python developers in major tech cities:")
query_text = "senior Python developer full-stack"
results = collection.query(
    query_texts=[query_text],
    n_results=5,
    where={
        "$and": [
            {"experience": {"$gte": 8}},
            {"location": {"$in": ["San Francisco", "New York", "Seattle"]}}
        ]
    }
)
print(f"Query: '{query_text}' with filters (8+ years, major tech cities)")
print(f"Found {len(results['ids'][0])} matching employees:")
for i, (doc_id, document, distance) in enumerate(zip(
    results['ids'][0], results['documents'][0], results['distances'][0]
)):
    metadata = results['metadatas'][0][i]
    print(f"  {i+1}. {metadata['name']} ({doc_id}) - Distance: {distance:.4f}")
    print(f"     {metadata['role']} in {metadata['location']} ({metadata['experience']} years)")
    print(f"     Document snippet: {document[:80]}...")

7. Handle the Results and Display Highly Similar Text

7.1 Create code that handles the results if no documents are found that are similar to the query term. This code also logs a message to the console:

# Check if the results are empty or undefined
if not results or not results['ids'] or len(results['ids'][0]) == 0:
    # Log a message if no similar documents are found for the query term
    print(f'No documents found similar to "{query_text}"')
    return

7.2 Use the following code to display the top documents whose distance meets the query criteria based on the query data threshold:

# Log the header for the top 3 similar documents based on the query term
print(f'Top 3 similar documents to "{query_text}":')
# Loop through the top 3 results and log the document details
for i in range(min(3, len(results['ids'][0]))):
    # Extract the document ID and similarity score from the results
    doc_id = results['ids'][0][i]
    score = results['distances'][0][i]
    # Retrieve the document text corresponding to the current ID from the results
    text = results['documents'][0][i]
    # Check if the text is available; if not, log 'Text not available'
    if not text:
        print(f' - ID: {doc_id}, Text: "Text not available", Score: {score:.4f}')
    else:
        print(f' - ID: {doc_id}, Text: "{text}", Score: {score:.4f}')

7.3 Next, call the perform_advanced_search function at the end of the try block of the main function:

# Call the perform_advanced_search function with the collection and all_items as arguments
perform_advanced_search(collection, all_items)

7.4 Then use the main function to create a collection, generate embeddings and call the perform_advanced_search function, which you included in the preceding 
instruction:

if __name__ == "__main__":
    main()

8. Check the output

8.1 Type the following command and press Enter:

python3.11 similarity_employeedata.py

8. Results: Refer to the screen shots in the project folder

9. Conclusion
Conclusion
9.1 You can integrate key-value pair data as vector data. You can use vector search with Chroma DB for analysis: The code demonstrates the integration of Chroma DB 
with Python for similarity search and embeddings. The code imports necessary modules from Chroma DB, creates a client instance, and defines an embedding function using SentenceTransformers.
9.2 You can easily generate embeddings for textual data: The code creates a collection within the Chroma DB client. The code defines comprehensive employee data and 
creates meaningful text documents that combine multiple attributes. The SentenceTransformer embedding function generates embeddings for the text documents 
automatically when they are added to the collection.
9.3 You can implement advanced search capabilities: You learned how to implement multiple types of searches including semantic similarity search using natural 
language queries, metadata filtering for precise criteria-based searches, and combined searches that leverage both similarity and filtering for powerful query 
capabilities.
9.4 You use a function named perform_advanced_search to run comprehensive searches including similarity search, metadata filtering, and combined search techniques.


